package com.depthwall.ai.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * DepthEstimationPipeline
 * Runs on-device monocular depth estimation using TensorFlow Lite (e.g. MiDaS v2.1 Small)
 * Inputs: Bitmap image
 * Outputs: Normalized float depth map [0.0 (far), 1.0 (near)] and extracted depth layers
 */
class DepthEstimationPipeline(private val context: Context) {

    private var tfliteInterpreter: Interpreter? = null
    private val inputDim = 256 // Standard MiDaS v2.1 input resolution

    init {
        try {
            loadModel("midas_v2_1_small_quantized.tflite")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadModel(modelPath: String) {
        val assetFileDescriptor = context.assets.openFd(modelPath)
        val fileInputStream = FileInputStream(assetFileDescriptor.fileDescriptor)
        val fileChannel = fileInputStream.channel
        val startOffset = assetFileDescriptor.startOffset
        val declaredLength = assetFileDescriptor.declaredLength
        val modelBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)

        val options = Interpreter.Options().apply {
            setNumThreads(4)
            setUseNNAPI(true) // Accelerate on Android NPU/GPU
        }
        tfliteInterpreter = Interpreter(modelBuffer, options)
    }

    /**
     * Executes inference on the supplied image
     * Returns a 256x256 grayscale depth bitmap
     */
    fun estimateDepth(inputBitmap: Bitmap): Bitmap {
        val scaled = Bitmap.createScaledBitmap(inputBitmap, inputDim, inputDim, true)

        // Float buffer: shape [1, 256, 256, 3]
        val inputBuffer = ByteBuffer.allocateDirect(1 * inputDim * inputDim * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }

        val intValues = IntArray(inputDim * inputDim)
        scaled.getPixels(intValues, 0, inputDim, 0, 0, inputDim, inputDim)

        for (pixel in intValues) {
            val r = (pixel shr 16 and 0xFF) / 255.0f
            val g = (pixel shr 8 and 0xFF) / 255.0f
            val b = (pixel and 0xFF) / 255.0f

            // MiDaS normalization: (x - mean) / std
            inputBuffer.putFloat((r - 0.485f) / 0.229f)
            inputBuffer.putFloat((g - 0.456f) / 0.224f)
            inputBuffer.putFloat((b - 0.406f) / 0.225f)
        }

        // Output buffer: shape [1, 256, 256]
        val outputBuffer = Array(1) { Array(inputDim) { FloatArray(inputDim) } }

        if (tfliteInterpreter != null) {
            tfliteInterpreter?.run(inputBuffer, outputBuffer)
        } else {
            // Algorithmic perspective gradient fallback
            for (y in 0 until inputDim) {
                for (x in 0 until inputDim) {
                    outputBuffer[0][y][x] = (y.toFloat() / inputDim)
                }
            }
        }

        // Convert normalized depth output to Grayscale Bitmap
        val depthBitmap = Bitmap.createBitmap(inputDim, inputDim, Bitmap.Config.ARGB_8888)
        for (y in 0 until inputDim) {
            for (x in 0 until inputDim) {
                val depthVal = (outputBuffer[0][y][x] * 255).toInt().coerceIn(0, 255)
                depthBitmap.setPixel(x, y, Color.rgb(depthVal, depthVal, depthVal))
            }
        }

        return depthBitmap
    }

    fun close() {
        tfliteInterpreter?.close()
        tfliteInterpreter = null
    }
}
