package com.depthwall.ai.wallpaper

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.depthwall.ai.gl.DepthWallGLRenderer

/**
 * DepthWallWallpaperService - Native Android Live Wallpaper Service
 * Renders high-performance 3D parallax scenes on Android Home and Lock screens
 * using OpenGL ES, responding to Gyroscope and Accelerometer sensors.
 */
class DepthWallWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return DepthWallEngine()
    }

    inner class DepthWallEngine : Engine(), SensorEventListener {

        private var glSurfaceView: DepthWallGLSurfaceView? = null
        private var renderer: DepthWallGLRenderer? = null
        private var sensorManager: SensorManager? = null
        private var rotationSensor: Sensor? = null
        private var accelerometerSensor: Sensor? = null

        private var isVisible = false
        private var isSensorsRegistered = false

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            setOffsetNotificationsEnabled(true)

            sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
                ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            accelerometerSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

            glSurfaceView = DepthWallGLSurfaceView(this@DepthWallWallpaperService)
            renderer = DepthWallGLRenderer(this@DepthWallWallpaperService)
            glSurfaceView?.setRenderer(renderer)
            glSurfaceView?.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.isVisible = visible
            super.onVisibilityChanged(visible)

            if (visible) {
                registerSensors()
                glSurfaceView?.onResume()
            } else {
                unregisterSensors()
                glSurfaceView?.onPause()
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset)
            // Launcher page swipe parallax
            renderer?.setLauncherScrollOffset(xOffset)
        }

        override fun onTouchEvent(event: MotionEvent) {
            super.onTouchEvent(event)
            renderer?.handleTouchEvent(event)
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (!isVisible) return

            when (event.sensor.type) {
                Sensor.TYPE_ROTATION_VECTOR -> {
                    val rotationMatrix = FloatArray(9)
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    val orientation = FloatArray(3)
                    SensorManager.getOrientation(rotationMatrix, orientation)
                    // orientation[1] = pitch (Y), orientation[2] = roll (X)
                    renderer?.updateSensorTilt(orientation[2], orientation[1])
                }
                Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE -> {
                    val x = event.values[0] / 9.8f
                    val y = event.values[1] / 9.8f
                    renderer?.updateSensorTilt(x, y)
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        private fun registerSensors() {
            if (isSensorsRegistered || sensorManager == null) return
            val sensorToUse = rotationSensor ?: accelerometerSensor
            sensorToUse?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
                isSensorsRegistered = true
            }
        }

        private fun unregisterSensors() {
            if (!isSensorsRegistered || sensorManager == null) return
            sensorManager?.unregisterListener(this)
            isSensorsRegistered = false
        }

        override fun onDestroy() {
            super.onDestroy()
            unregisterSensors()
            glSurfaceView?.onDestroy()
            glSurfaceView = null
            renderer = null
        }

        inner class DepthWallGLSurfaceView(context: Context) : GLSurfaceView(context) {
            init {
                setEGLContextClientVersion(2)
            }

            override fun getHolder(): SurfaceHolder {
                return surfaceHolder
            }

            fun onDestroy() {
                // OpenGL cleanup
            }
        }
    }
}
