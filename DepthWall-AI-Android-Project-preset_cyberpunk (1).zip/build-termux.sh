#!/bin/bash
set -e

echo "=========================================="
echo " DepthWall AI - Termux On-Device Builder "
echo "=========================================="

echo "[1/4] Ensuring storage permissions and directories..."
if [ ! -d "$HOME/storage/shared" ]; then
    echo "Running termux-setup-storage... Please tap ALLOW on your screen."
    termux-setup-storage
    sleep 2
fi

echo "[2/4] Installing OpenJDK 17 and Gradle..."
pkg update -y
pkg install -y openjdk-17 gradle git aapt apksigner

export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
echo "Java runtime: $JAVA_HOME"

echo "[3/4] Compiling DepthWall AI Live Wallpaper APK..."
chmod +x ./gradlew 2>/dev/null || true

if [ -f "./gradlew" ]; then
    ./gradlew assembleDebug --stacktrace
else
    gradle assembleDebug --stacktrace
fi

echo "[4/4] Verifying APK output..."
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    mkdir -p "$HOME/storage/shared/Download"
    cp app/build/outputs/apk/debug/app-debug.apk "$HOME/storage/shared/Download/DepthWall-AI.apk"
    echo "========================================================"
    echo " SUCCESS! DepthWall AI APK compiled successfully!"
    echo " Saved to your phone at:"
    echo " /sdcard/Download/DepthWall-AI.apk"
    echo " Open your phone's Files/Downloads app to install!"
    echo "========================================================"
else
    echo "Build did not produce APK. Check Gradle logs above."
fi
