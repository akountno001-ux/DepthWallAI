#!/bin/bash
set -e
echo "Installing DepthWall AI Termux requirements..."
pkg update -y
pkg install -y openjdk-17 gradle git aapt apksigner android-tools wget unzip
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
export ANDROID_HOME=$PREFIX/share/android-sdk
mkdir -p "$ANDROID_HOME" 2>/dev/null || true
echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x ./gradlew 2>/dev/null || true
echo "Setup complete! You can now run: ./gradlew assembleDebug"
