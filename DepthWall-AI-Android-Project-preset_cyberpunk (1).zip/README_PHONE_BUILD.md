# DepthWall AI - Complete Phone-Only APK Compilation Guide

You are working directly from an Android phone without a computer. Here is the verified step-by-step workflow.

---

## 🚀 Step-by-Step Guide with Termux (100% On-Device)

### Step 1: Install Termux from F-Droid
> ⚠️ CRITICAL NOTE: Do NOT install Termux from Google Play Store! The Play Store build is obsolete and its package mirrors fail.
> Download the official APK from F-Droid:
> 👉 https://f-droid.org/packages/com.termux/ (or from GitHub Releases: https://github.com/termux/termux-app/releases)

### Step 2: Open Termux and Grant Storage Access
Open Termux on your phone and type:
```bash
termux-setup-storage
```
👉 Tap Allow when Android asks for storage permissions.

### Step 3: Install JDK 17 & Gradle
In Termux, paste this single command:
```bash
pkg update -y && pkg install -y openjdk-17 gradle git aapt apksigner
```

### Step 4: Extract the DepthWall Project
Extract this downloaded ZIP into your phone's storage. In Termux, navigate to the extracted folder:
```bash
cd ~/storage/shared/Download/DepthWallAI
```
*(Replace DepthWallAI with the exact name of the extracted folder in your Downloads)*

### Step 5: Run the Automated Build Script
```bash
bash build-termux.sh
```
*(Or run gradle assembleDebug directly)*

### Step 6: Install the Generated APK
Once the build completes:
1. Open your phone's Files or Downloads app.
2. Tap DepthWall-AI.apk (or look inside app/build/outputs/apk/debug/app-debug.apk).
3. Tap Install & open DepthWall AI.
4. Tap Apply Live Wallpaper -> Choose Home Screen or Home Screen + Lock Screen!

---

## ⚡ Alternative Method: 1-Click Cloud Build with GitHub Actions
If you don't want to install packages in Termux, you can build in 2 minutes via your phone's browser:
1. Go to github.com on your phone and create a free repository.
2. Upload this project ZIP.
3. Tap the Actions tab -> Build DepthWall AI Android APK -> Run workflow.
4. In ~2 minutes, tap DepthWall-AI-Debug-APK to download and install!